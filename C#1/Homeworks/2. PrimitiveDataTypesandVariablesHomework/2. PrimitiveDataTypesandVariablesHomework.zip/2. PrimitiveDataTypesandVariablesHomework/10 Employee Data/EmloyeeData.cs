﻿using System;

class EmloyeeData
{
    static void Main(string[] args)
    {
        string firstName = "Ivan";
        string lastName = "Ivanov";
        byte age = 28;
        char gender = 'M';
        long ID = 8604287966;
        int employeeNum = 27569999;
        Console.WriteLine("{0}\n{1}\n{2}\n{3}\n{4}\n{5}",firstName,lastName,age,gender,ID,employeeNum);



    }
}