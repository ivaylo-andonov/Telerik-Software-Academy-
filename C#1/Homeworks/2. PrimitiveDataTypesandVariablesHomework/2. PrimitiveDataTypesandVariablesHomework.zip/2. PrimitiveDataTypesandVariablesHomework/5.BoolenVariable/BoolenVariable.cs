﻿using System;

class BoolenVariable
{
    static void Main()
    {
        string gender = "Male";
        bool isFemale;
        isFemale = (gender == "Female");
        Console.WriteLine(isFemale);
    }
}

