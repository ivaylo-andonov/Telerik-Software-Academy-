﻿using System;

class UnicodeCharacter
{
      static void Main()
      {
          char unicodeNum = '\u002A';
          Console.WriteLine(unicodeNum);
      }
}