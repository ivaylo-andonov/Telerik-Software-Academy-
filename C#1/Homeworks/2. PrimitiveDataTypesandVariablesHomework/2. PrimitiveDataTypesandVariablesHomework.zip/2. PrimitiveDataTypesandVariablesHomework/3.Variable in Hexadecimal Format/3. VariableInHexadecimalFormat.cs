﻿using System;

class VariableInHexadecimalFormat
{
    static void Main()
    {
        int hexadecimalNum;
        hexadecimalNum = 0xFE;
        Console.WriteLine(hexadecimalNum);

    }
}

