﻿using System;

class DeclareVariables
{
    static void Main()
    {
        ushort numberOne = 52130;
        sbyte numberTwo = -115;
        int numberThree = 4825932;
        byte numberFour = 97;
        short numberFive = -10000;
        Console.WriteLine(numberOne + "\n" + numberTwo + "\n" + numberThree + "\n" + numberFour + "\n" + numberFive );
        
    }
}

