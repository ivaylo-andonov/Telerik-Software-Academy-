﻿using System;

class FloatOrDouble
{
    static void Main()
    {
        double numberOne = 34.567839023;
        float numberTwo = 12.345f;
        double numberThree = 8923.1234857;
        float numberFour = 3456.091f;
        
        Console.WriteLine( numberOne + "\n" + numberTwo + "\n" + numberThree + "\n" + numberFour);
    }
}
